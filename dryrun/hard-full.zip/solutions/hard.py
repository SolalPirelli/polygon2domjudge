n, C = [int(x) for x in raw_input().split(" ")]
weights = [int(x) for x in raw_input().split(" ")]
weights.sort()
max_power, n_carry = 0, n
for i, weight in enumerate(weights):
    w = weight - C
    if w >= 0:
        power = w * (n - i)
        if power > max_power:
            max_power = power
print max_power