import java.util.Scanner;


public class java_scanner_dj3500 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
      long m = input.nextLong();
      long res = 0;
      for (int i = 0; i < n; ++i) {
         long ai = input.nextLong();
         res = (res + ai) % m;
      }
      System.out.println(res);
   }
}
