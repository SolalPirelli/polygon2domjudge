import java.util.*;
import java.io.*;
import java.math.BigInteger;

public class java_bufferedreader_dj3500 implements Runnable {
   StringTokenizer tokenizer = new StringTokenizer("");
   BufferedReader in;
   PrintStream out;
   public void debug(String s) {
      System.out.println(s);
   }
   public static void main(String[] args) {
      new Thread(new java_bufferedreader_dj3500()).start();
   }

   public void run() {
      try {
         in = new BufferedReader(new InputStreamReader(System.in));
         out = new PrintStream(System.out);

         // tutaj poczatek programu

         int n = nextInt();
         long m = nextLong();
         long res = 0;
         for (int i = 0; i < n; ++i) {
            long ai = nextLong();
            res = (res + ai) % m;
         }
         out.println(res);

         // tutaj koniec programu

      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   boolean seekForToken() {
      while (!tokenizer.hasMoreTokens()) {
         String s = null;
         try {
            s = in.readLine();
         } catch (Exception e) {
            e.printStackTrace();
         }
         if (s == null) return false;
         tokenizer = new StringTokenizer(s);
      }
      return true;
   }
   String nextToken() {
      return seekForToken() ? tokenizer.nextToken() : null;
   }
   // z tych wystarczy przepisac te potrzebne
   int nextInt() {
      return Integer.parseInt(nextToken());
   }
   long nextLong() {
      return Long.parseLong(nextToken());
   }
   double nextDouble() {
      return Double.parseDouble(nextToken());
   }
   BigInteger nextBig() {
      return new BigInteger(nextToken());
   }
}
