#include "testlib.h"

const long long MAXN = 1000000000, MINN = -1000000000;

int main () {
   registerValidation();
   inf.readInt(MINN, MAXN, "x");
   inf.readSpace();
   inf.readInt(MINN, MAXN, "y");
   inf.readEoln();
   inf.readEof();
}
