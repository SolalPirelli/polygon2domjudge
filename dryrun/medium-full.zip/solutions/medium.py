n, m = [int(x) for x in raw_input().split(" ")]
sum = 0
for _ in xrange(n):
    sum = (sum + int(raw_input())) % m
print sum