#include "testlib.h"

const int LIMIT = 300000, LIMIT2 = 1000000;

int main () {
   registerValidation();
   int n = inf.readInt(1, LIMIT, "n");
   inf.readSpace();
   int C = inf.readInt(1, LIMIT2, "C");
   inf.readEoln();
   
   for (int i = 1; i <= n; ++i) {
      int a = inf.readInt(1, LIMIT2, "a_i");
      if (i < n) inf.readSpace();
   }
   inf.readEoln();
   inf.readEof();
}
