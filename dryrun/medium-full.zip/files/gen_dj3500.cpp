#include "testlib.h"
#include <iostream>
using namespace std;

int main (int argc, char ** argv) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    long long m = atoll(argv[2]);
    
    rnd.setSeed(argc, argv);
    
    cout << n << " " << m << "\n";
    for (int i = 0; i < n; ++i) {
       long long ai = rnd.next(m);
       cout << ai << "\n";
    }
    
    return 0;
}                                                                  
