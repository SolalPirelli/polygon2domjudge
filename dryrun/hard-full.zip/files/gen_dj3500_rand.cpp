#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include "testlib.h"
using namespace std;

int main (int argc, char ** argv) {
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int upper = atoi(argv[2]);
    
    cout << n << " " << rnd.next(1,upper) << endl;
    for (int i = 0; i < n; i++) {
       cout << rnd.next(1,upper) << " \n"[i==n-1];
    }
    return 0;
}                                                                  
