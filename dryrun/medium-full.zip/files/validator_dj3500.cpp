#include "testlib.h"

const long long MAXN = 500000, MAXM = 1000000000000000000LL;
long long min (long long a, long long b) { return a < b ? a : b; }

int main () {
   registerValidation();
   int n = inf.readInt(1, MAXN, "n");
   inf.readSpace();
   long long m = inf.readLong(1, MAXM, "m");
   inf.readEoln();
   
   for (int i = 1; i <= n; ++i) {
      inf.readLong(0, m - 1, "A_i");
      inf.readEoln();
   }
   inf.readEof();
}
