object jrabasco {
    def main(args: Array[String]) {
      val nm = readLine.split(" ").toList
      val n = nm(0).toInt
      val m = nm(1).toLong
      var res = 0L
      for ( i <- 1 to n ) { res = (res + readLine.toLong) % m }
      println(res)
    }
  }